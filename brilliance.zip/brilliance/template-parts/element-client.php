<div class="client">
	<?php the_post_thumbnail('portfolio', array('class' => 'client-image')); ?>
	<?php cpotheme_edit(); ?>
</div>